create definer = rdsadmin@localhost trigger block_event_i
    before insert
    on event
    for each row
BEGIN
  IF new.Definer = 'rdsadmin@localhost' THEN
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'event', message_text = 'ERROR (RDS): CANNOT CREATE RDSADMIN@LOCALHOST OBJECT';
  END IF;
END;

