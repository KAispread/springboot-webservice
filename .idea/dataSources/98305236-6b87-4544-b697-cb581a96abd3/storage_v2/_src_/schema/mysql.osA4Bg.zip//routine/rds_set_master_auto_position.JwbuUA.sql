create
    definer = rdsadmin@localhost procedure rds_set_master_auto_position(IN auto_position_mode tinyint(1))
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RDS_SET_MASTER_AUTO_POSITION cannot be used on RDS MariaDB instances. CALL mysql.rds_set_external_master_gtid or mysql.rds_set_external_master instead.';
END;

