create definer = rdsadmin@localhost trigger block_user_u
    before update
    on global_priv
    for each row
BEGIN
  DECLARE vn varchar(255);
  DECLARE v1, v2, v3 int;

  if old.User = "rdsadmin" and old.Host = "localhost" then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): CANNOT UPDATE RDSADMIN@LOCALHOST USER';
  end if;

  if old.User = "rdsrepladmin" then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): CANNOT UPDATE RDSREPLADMIN USER';
  end if;

  if (json_value(`new`.`Priv`, '$.access') & (1<<15)) then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): SUPER PRIVILEGE CANNOT BE GRANTED OR MAINTAINED';
  elseif (json_value(`new`.`Priv`, '$.access') & (1<<7)) then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): SHUTDOWN PRIVILEGE CANNOT BE GRANTED OR MAINTAINED. PLEASE USE RDS API';
  elseif (json_value(`new`.`Priv`, '$.access') & (1<<9)) then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): FILE PRIVILEGE CANNOT BE GRANTED OR MAINTAINED';
  elseif (json_value(`new`.`Priv`, '$.access') & (1<<19)) then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): REPLICATION SLAVE PRIVILEGE CANNOT BE GRANTED OR MAINTAINED';
  elseif (json_value(`new`.`Priv`, '$.access') & (1<<20)) then
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    select concat(substring_index(version(), '-', 1), '..') into vn;
    select cast(                substring_index(vn, '.', 1)           as int),
           cast(substring_index(substring_index(vn, '.', 2), '.', -1) as int),
           cast(substring_index(substring_index(vn, '.', 3), '.', -1) as int) into v1, v2, v3;

    if v1 > 10 or (v1 = 10 and v2 > 5) or (v1 = 10 and v2 = 5 and v3 >= 2) then
       
       
       
       signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): BINLOG MONITOR PRIVILEGE CANNOT BE GRANTED OR MAINTAINED';
    else
       signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): REPLICATION CLIENT PRIVILEGE CANNOT BE GRANTED OR MAINTAINED';
    end if;
  elseif (json_value(`new`.`Priv`, '$.access') & (1<<31)) then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): FEDERATED ADMIN PRIVILEGE CANNOT BE GRANTED OR MAINTAINED';
  elseif (json_value(`new`.`Priv`, '$.access') & (1<<32)) then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): CONNECTION ADMIN PRIVILEGE CANNOT BE GRANTED OR MAINTAINED';
  elseif (json_value(`new`.`Priv`, '$.access') & (1<<33)) then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): READ ONLY ADMIN PRIVILEGE CANNOT BE GRANTED OR MAINTAINED';
  elseif (json_value(`new`.`Priv`, '$.access') & (1<<34)) then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): REPLICATION SLAVE ADMIN PRIVILEGE CANNOT BE GRANTED OR MAINTAINED';
  elseif (json_value(`new`.`Priv`, '$.access') & (1<<35)) then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): REPLICATION MASTER ADMIN PRIVILEGE CANNOT BE GRANTED OR MAINTAINED';
  elseif (json_value(`new`.`Priv`, '$.access') & (1<<36)) then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): BINLOG ADMIN PRIVILEGE CANNOT BE GRANTED OR MAINTAINED';
  elseif (json_value(`new`.`Priv`, '$.access') & (1<<37)) then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): BINLOG REPLAY PRIVILEGE CANNOT BE GRANTED OR MAINTAINED';
  end if;
END;

