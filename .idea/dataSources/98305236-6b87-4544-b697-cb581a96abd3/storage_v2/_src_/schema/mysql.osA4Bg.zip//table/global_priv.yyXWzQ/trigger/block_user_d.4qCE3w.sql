create definer = rdsadmin@localhost trigger block_user_d
    before delete
    on global_priv
    for each row
BEGIN
  if old.User = "rdsadmin" and old.Host = "localhost" then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): CANNOT DROP RDSADMIN@LOCALHOST USER';
  end if;
  if old.User = "rdsrepladmin" then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'user', message_text = 'ERROR (RDS): CANNOT DROP RDSREPLADMIN USER';
  end if;
END;

