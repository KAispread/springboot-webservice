create
    definer = rdsadmin@localhost procedure rds_set_external_master_gtid(IN host varchar(255), IN port int, IN USER text,
                                                                        IN passwd text, IN gtid varchar(42),
                                                                        IN enable_ssl_encryption tinyint(1))
BEGIN
  DECLARE v_rdsrepl INT;
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE sql_logging BOOLEAN;

  SELECT @@sql_log_bin, user(), version() into sql_logging, v_called_by_user, v_mysql_version;
  SELECT COUNT(1) INTO v_rdsrepl FROM mysql.rds_history WHERE action = 'disable set master' AND master_user = 'rdsrepladmin';

  IF v_rdsrepl > 0 AND  v_called_by_user != 'rdsadmin@localhost'
  THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RDS_SET_EXTERNAL_MASTER is disabled on this host.';
  END IF;

  
  BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; RESIGNAL; END;
    SET @@sql_log_bin=off;

    UPDATE mysql.rds_replication_status SET called_by_user=v_called_by_user, action='set master', mysql_version=v_mysql_version , master_host=TRIM(BOTH FROM host), master_port=port WHERE action IS NOT NULL;
    commit;
    SET GLOBAL gtid_slave_pos = gtid;
    
    SET @cmd = CONCAT('CHANGE MASTER TO MASTER_HOST = ', QUOTE(TRIM(BOTH FROM host)),
                      ', MASTER_PORT = ', port,                         
                      ', MASTER_USER = ', QUOTE(TRIM(BOTH FROM user)),
                      ', MASTER_PASSWORD = ', QUOTE(passwd),
                      ', MASTER_SSL = ', enable_ssl_encryption,         
                      ', MASTER_USE_GTID = slave_pos'
                      );
    PREPARE rds_set_master FROM @cmd;
    EXECUTE rds_set_master;
    DEALLOCATE PREPARE rds_set_master;
    INSERT INTO mysql.rds_history(called_by_user, action, mysql_version, master_host, master_port, master_user, master_gtid, master_ssl)
           VALUES (v_called_by_user,'set master', v_mysql_version, TRIM(BOTH FROM host), port, TRIM(BOTH FROM USER), TRIM(BOTH FROM gtid), enable_ssl_encryption);
    commit;

    SET @@sql_log_bin=sql_logging;
  END;

END;

