create definer = rdsadmin@localhost trigger block_proc_u
    before update
    on proc
    for each row
BEGIN
  if old.Definer = 'rdsadmin@localhost' or (old.Definer <> 'rdsadmin@localhost' and new.Definer = 'rdsadmin@localhost') then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'proc', message_text = 'ERROR (RDS): CANNOT MODIFY RDSADMIN OBJECT';
  end if;
END;

