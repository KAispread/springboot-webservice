create definer = rdsadmin@localhost trigger block_event_d
    before delete
    on event
    for each row
BEGIN
  if old.Definer = 'rdsadmin@localhost' then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'event', message_text = 'ERROR (RDS): CANNOT DROP RDSADMIN@LOCALHOST OBJECT';
  end if;
END;

