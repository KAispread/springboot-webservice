create
    definer = rdsadmin@localhost procedure rds_set_external_master_with_auto_position(IN host varchar(255), IN port int,
                                                                                      IN user text, IN passwd text,
                                                                                      IN enable_ssl_encryption tinyint(1),
                                                                                      IN delay int)
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RDS_SET_EXTERNAL_MASTER_WITH_AUTO_POSITION cannot be used on RDS MariaDB instances. CALL mysql.rds_set_external_master_gtid instead.';
END;

