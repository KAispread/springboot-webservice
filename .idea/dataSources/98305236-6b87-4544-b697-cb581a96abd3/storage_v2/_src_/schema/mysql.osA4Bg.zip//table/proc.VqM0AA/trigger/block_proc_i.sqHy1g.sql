create definer = rdsadmin@localhost trigger block_proc_i
    before insert
    on proc
    for each row
BEGIN
  if new.Definer = "rdsadmin@localhost" then
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'proc', message_text = 'ERROR (RDS): CANNOT CREATE RDSADMIN@LOCALHOST OBJECT';
  end if;
END;

