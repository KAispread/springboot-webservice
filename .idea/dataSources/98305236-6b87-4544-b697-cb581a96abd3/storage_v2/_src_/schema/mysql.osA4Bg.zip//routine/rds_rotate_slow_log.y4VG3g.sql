create
    definer = rdsadmin@localhost procedure rds_rotate_slow_log()
BEGIN
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE sql_logging BOOLEAN;
  DECLARE slow_logging BOOLEAN;
  select @@sql_log_bin, @@GLOBAL.slow_query_log, user(), version() into sql_logging, slow_logging, v_called_by_user, v_mysql_version;

  

  
  BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; SET GLOBAL slow_query_log=slow_logging; RESIGNAL; END;
    set @@sql_log_bin=off;
    set global slow_query_log=off;

    DROP TABLE IF EXISTS mysql.slow_log2;
    CREATE TABLE IF NOT EXISTS mysql.slow_log2 LIKE mysql.slow_log;
    DROP TABLE IF EXISTS mysql.slow_log_backup;
    FLUSH SLOW LOGS;
    RENAME TABLE mysql.slow_log TO mysql.slow_log_backup, mysql.slow_log2 TO mysql.slow_log;
    INSERT into mysql.rds_history(called_by_user, action, mysql_version) values (v_called_by_user, 'rotate_slow_log', v_mysql_version);
    COMMIT;

    set @@sql_log_bin=sql_logging;
    set global slow_query_log=slow_logging;
  END;
END;

