create
    definer = rdsadmin@localhost procedure rds_kill(IN thread bigint)
BEGIN
  DECLARE l_user varchar(16);
  DECLARE l_host varchar(64);

  SELECT user, host INTO l_user, l_host
  FROM information_schema.processlist
  WHERE id = thread;

  IF CONNECTION_ID() = thread AND user() != 'rdsadmin@localhost' AND user() NOT LIKE 'rdsrepladmin@%' THEN
    
    
    
    
    
    
    
    set @noop = null;
  ELSEIF l_user = "rdsadmin" THEN
    signal sqlstate '45000' set schema_name = 'information_schema', table_name = 'processlist', message_text = 'ERROR (RDS): CANNOT KILL RDSADMIN SESSION';
  ELSEIF l_user = "rdsrepladmin" THEN
    signal sqlstate '45000' set schema_name = 'information_schema', table_name = 'processlist', message_text = 'ERROR (RDS): CANNOT KILL RDSREPLADMIN SESSION';
  END IF;

  
  KILL thread;
END;

