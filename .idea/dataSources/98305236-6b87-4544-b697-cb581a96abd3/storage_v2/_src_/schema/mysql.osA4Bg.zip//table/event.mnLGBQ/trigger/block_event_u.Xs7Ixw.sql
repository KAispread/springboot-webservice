create definer = rdsadmin@localhost trigger block_event_u
    before update
    on event
    for each row
BEGIN
  IF old.Definer = 'rdsadmin@localhost' OR (old.Definer <> 'rdsadmin@localhost' AND new.Definer = 'rdsadmin@localhost') THEN
    signal sqlstate '45000' set schema_name = 'mysql', table_name = 'event', message_text = 'ERROR (RDS): CANNOT MODIFY RDSADMIN@LOCALHOST OBJECT';
  END IF;
END;

