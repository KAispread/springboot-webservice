create
    definer = rdsadmin@localhost procedure rds_kill_query_id(IN query bigint)
BEGIN
  DECLARE l_user VARCHAR(16);
  DECLARE l_host VARCHAR(64);
  DECLARE l_thread BIGINT(10);

  SELECT USER, host, id INTO l_user, l_host, l_thread
  FROM information_schema.processlist
  WHERE query_id = query;

  IF CONNECTION_ID() = l_thread AND user() != 'rdsadmin@localhost' AND user() NOT LIKE 'rdsrepladmin@%' THEN
    
    
    
    
    
    
    
    set @noop = null;
  ELSEIF l_user = "rdsadmin" THEN
    signal sqlstate '45000' set schema_name = 'information_schema', table_name = 'processlist', message_text = 'ERROR (RDS): CANNOT KILL RDSADMIN QUERY';
  ELSEIF l_user = "rdsrepladmin" THEN
    signal sqlstate '45000' set schema_name = 'information_schema', table_name = 'processlist', message_text = 'ERROR (RDS): CANNOT KILL RDSREPLADMIN QUERY';
  END IF;

  
  
  KILL QUERY ID query;
END;

