create
    definer = rdsadmin@localhost procedure rds_kill_user(IN l_user text, IN l_host text)
BEGIN
  DECLARE also_kill_this_thread INT;

  
  
  
  
  
  
  

  IF l_user LIKE '%\`%' OR l_host LIKE '%\`%' THEN
    signal sqlstate '45000' set message_text = 'ERROR (RDS): BACKTICK (`) CHARACTERS NOT ALLOWED IN ARGUMENTS TO rds_kill_user';
  ELSEIF l_host LIKE '%\%%' THEN
    signal sqlstate '45000' set message_text = 'ERROR (RDS): PERCENT (%) CHARACTER NOT ALLOWED IN host ARGUMENT to rds_kill_user. USE CALL rds_kill_user(username, NULL) TO ACT REGARDLESS OF HOST.';
  ELSEIF l_user = '' OR l_host = '' THEN
    signal sqlstate '45000' set message_text = 'ERROR (RDS): EMPTY STRING NOT ALLOWED AS host ARGUMENT to rds_kill_user. USE CALL rds_kill_user(username, NULL) TO ACT REGARDLESS OF HOST.';
  ELSEIF l_user LIKE '%@%' THEN
    select "Calling rds_kill_user() with username containing '@' is probably a mistake. Use CALL rds_kill_user(username, hostname)" as Warning;
  END IF;

  IF l_user = "rdsadmin" AND (l_host IS NULL OR l_host = "localhost") THEN
    
    
    signal sqlstate '45000' set schema_name = 'information_schema', table_name = 'processlist', message_text = 'ERROR (RDS): CANNOT KILL USER RDSADMIN@LOCALHOST';
  ELSEIF l_user = "rdsrepladmin" THEN
    signal sqlstate '45000' set schema_name = 'information_schema', table_name = 'processlist', message_text = 'ERROR (RDS): CANNOT KILL USER RDSREPLADMIN';
  ELSEIF USER() = CONCAT(l_user, '@', l_host) OR (l_host IS NULL AND SUBSTRING(USER(), 1, LENGTH(l_user) + 1) = CONCAT(l_user, '@')) THEN
    
    
    
    
    
    
    
    
    
    SELECT id INTO also_kill_this_thread FROM information_schema.processlist WHERE id = CONNECTION_ID();
  END IF;

  SET @cmd = CONCAT(
    'KILL USER \`', l_user, '\`',
    CASE WHEN l_host IS NULL THEN '' ELSE CONCAT('@\`', l_host, '\`') END
  );
  PREPARE stmt FROM @cmd;
  EXECUTE stmt;
  DEALLOCATE PREPARE stmt;

  IF also_kill_this_thread IS NOT NULL THEN
    KILL also_kill_this_thread;
  END IF;
END;

