create
    definer = rdsadmin@localhost procedure rds_stop_replication()
BEGIN
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE v_threads_running INT;
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE sql_logging BOOLEAN;
  SELECT @@sql_log_bin, user(), version() into sql_logging, v_called_by_user, v_mysql_version;

  SELECT COUNT(1) into v_threads_running FROM information_schema.processlist WHERE user = 'system user';
  if v_threads_running = 0 
  then
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Slave is already stopped or may not be configured. CALL mysql.rds_replica_status\\G;';
  else 
    
    BEGIN
      DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; RESIGNAL; END;
      set @@sql_log_bin=off;

      update mysql.rds_replication_status set called_by_user=v_called_by_user,action='stop slave', mysql_version=v_mysql_version where action is not null;
      commit;
      select sleep(1);
      STOP SLAVE;
      SELECT COUNT(1) into v_threads_running FROM information_schema.processlist WHERE user = 'system user';
      if v_threads_running = 0
      then
        insert into mysql.rds_history (called_by_user,action,mysql_version) values (v_called_by_user,'stop slave',v_mysql_version);
        commit;
        
        Select 'Replication stopped. Slave is now down or disabled' as Message;
      else
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Slave has encountered an error. CALL mysql.rds_replica_status\\G; to see the error.';
      end if;

      set @@sql_log_bin=sql_logging;
    END;
  end if;
END;

