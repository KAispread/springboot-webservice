create
    definer = rdsadmin@localhost procedure rds_replica_status()
BEGIN
SHOW REPLICA STATUS;
END;

