create
    definer = rdsadmin@localhost procedure rds_innodb_buffer_pool_dump_now()
BEGIN
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE sql_logging BOOLEAN;
  SELECT @@sql_log_bin, user(), version() into sql_logging, v_called_by_user, v_mysql_version;

  
  BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; RESIGNAL; END;
    SET @@sql_log_bin=off;

    INSERT into mysql.rds_history(called_by_user, action, mysql_version) values (v_called_by_user,'innodb_buf_dump_now', v_mysql_version);
    commit;
    SET GLOBAL `INNODB_BUFFER_POOL_DUMP_NOW`=1;

    SET @@sql_log_bin=sql_logging;
  END;
END;

